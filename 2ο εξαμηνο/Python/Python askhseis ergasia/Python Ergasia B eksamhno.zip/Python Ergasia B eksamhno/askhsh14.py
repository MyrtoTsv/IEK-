lista = []

num = int(input("Dwse mou enan arithmo: "))

for i in range(num):
    lista.append(i+1)

print("H lista einai ",num ,"stoixeiwn")
print(lista)