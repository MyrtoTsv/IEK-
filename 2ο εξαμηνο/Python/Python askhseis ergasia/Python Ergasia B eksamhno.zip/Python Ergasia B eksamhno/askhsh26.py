lista = []

def reversedlista(lista):
    
    revlista = []
        
    for i in range(5):
        revlista = lista [::-1]
    return revlista

for i in range(5):
    num = float(input("Dwse mou enan arithmo: "))
    lista.append(num) 

    
print(reversedlista(lista))